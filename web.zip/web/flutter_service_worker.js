'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "e18d2011bac31fea0ad48996adc23648",
"assets/assets/a.png": "9123f06d6ce308aedd4a0f68883ed3dd",
"assets/assets/b.png": "f75d7adf1ab1a3e401efa634909c4d1b",
"assets/assets/c.png": "4ab2008edad98f33c0b6b69a87939a70",
"assets/assets/d.png": "b40566e91f2feb302761159e31d48079",
"assets/assets/e.png": "d8d442027c02cf4ec9680c629069e14c",
"assets/assets/f.png": "bf52ed07831ba0f3e88fa8b0fbd69f98",
"assets/assets/g.png": "558bc3d0aa143033d6f085eed96e0b11",
"assets/assets/h.png": "24461beaf8ace305d2426437d2398713",
"assets/assets/homepage.png": "dbf9844a2ba2cb55e4ae41360e2d69ac",
"assets/assets/i.png": "351f79ea699949c0375175431a72020e",
"assets/assets/j.png": "4db69c782642356e995ebc61cbb76a41",
"assets/assets/k.png": "8d500d2a453c0d258f5b551620067adb",
"assets/assets/l.png": "82b03ce565766e5da10a5d2cc44c7da1",
"assets/assets/m.png": "437188a6dd3d4fcd023d23aa24192f71",
"assets/assets/n.png": "2bf65dfcdb5888bfef0a49ce10929469",
"assets/assets/o.png": "49c6631df951ab77a42d52aea8b920b8",
"assets/assets/p.png": "44eeb66a1bdb44c3425a396daaf3cce5",
"assets/assets/q.png": "cfea5a22bf2685b48dc8be452fff9766",
"assets/assets/r.png": "b9cb57ea741b8f96e8e41067ef1ce883",
"assets/assets/s.png": "fd1af9d07691a8966b2ca83505215bdd",
"assets/assets/t.png": "67438d3fe257f9e9abf1ec4eccfd226b",
"assets/assets/u.png": "075fbad48a576bd28c0fb7cf9b7f223e",
"assets/assets/v.png": "f3f8344b7988f4f20b8f3cf68c4caddc",
"assets/assets/w.png": "b4b92ef37ddc522e846e74a38fe11ab0",
"assets/assets/x.png": "92fd0103e1c40802dbf75a245e978ea5",
"assets/assets/y.png": "1c8aa55d7e39fd7a9bf1c6e7accc36ac",
"assets/assets/z.png": "31cd9e2c081e040f4fba3db1727ea98a",
"assets/FontManifest.json": "2a781a4851ec65e7781d14aaa016a2d4",
"assets/fonts/MaterialIcons-Regular.otf": "7e7a6cccddf6d7b20012a548461d5d81",
"assets/lib/Login/bg.jpg": "62128d47247cae5885b99dda00ba1088",
"assets/NOTICES": "f525a37336d1a15a5071b8d0d15c1ee3",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/fluent_ui/assets/AcrylicNoise.png": "81f27726c45346351eca125bd062e9a7",
"assets/packages/fluent_ui/fonts/FluentIcons.ttf": "1cd173aed13e298ab2663dd0924f6762",
"canvaskit/canvaskit.js": "c2b4e5f3d7a3d82aed024e7249a78487",
"canvaskit/canvaskit.wasm": "4b83d89d9fecbea8ca46f2f760c5a9ba",
"canvaskit/profiling/canvaskit.js": "ae2949af4efc61d28a4a80fffa1db900",
"canvaskit/profiling/canvaskit.wasm": "95e736ab31147d1b2c7b25f11d4c32cd",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "d7f8f40eb1bca13fad4f31f91a12f978",
"/": "d7f8f40eb1bca13fad4f31f91a12f978",
"main.dart.js": "25f5a01974da1871e16a76c6ddf7c84a",
"manifest.json": "17a76dbcbe36eb25420e75ec4cf2d04a",
"version.json": "6ce0ff16eb645082233b7290043558f6"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
